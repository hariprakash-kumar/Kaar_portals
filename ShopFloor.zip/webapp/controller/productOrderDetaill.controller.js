sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History"
], function(Controller,History) {
	"use strict";

	return Controller.extend("hariShopFloor.controller.productOrderDetaill", {

	onInit: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("prodet").attachPatternMatched(this._onObjectMatched, this);
		},
		_onObjectMatched: function(oEvent) {
			var oArgs;
			var myData;
			oArgs = oEvent.getParameter("arguments");
			var productOrderNo = oArgs.prodOrd;
			window.console.log(productOrderNo + "From details");

			var surl = "/sap/opu/odata/sap/ZPP_ODATA_HP_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(surl, true);
			//Local var to loopitems
			// entity name

			oModel.read("ZHP_PROD_ORD_DETSet('" + productOrderNo + "')", {
				context: null,
				urlParameters: null,
				async: false,
				success: function(oData, oResponse) {
					window.console.log("OData values:");
					window.console.log(oData);
						
						var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
							pattern: "MMM dd, yyyy "
						});
						var dateStr = dateFormat.format(new Date(oData.SchedReleaseDate));
						oData.SchedReleaseDate = dateStr;
						dateStr = dateFormat.format(new Date(oData.ActualReleaseDate));
						oData.ActualReleaseDate = dateStr;
						dateStr = dateFormat.format(new Date(oData.FinishDate));
						oData.FinishDate = dateStr;
						dateStr = dateFormat.format(new Date(oData.StartDate));
						oData.StartDate = dateStr;
						dateStr = dateFormat.format(new Date(oData.ProductionStartDate));
						oData.ProductionStartDate = dateStr;
						dateStr = dateFormat.format(new Date(oData.ProductionFinishDate));
						oData.ProductionFinishDate = dateStr;
						
					myData = oData;
				}
			});
			window.console.log(myData);
			this.getView().byId("OrderNumber").setText(myData.OrderNumber);
			this.getView().byId("OrderType").setText(myData.OrderType);
			this.getView().byId("RoutingNo").setText(myData.RoutingNo);
			this.getView().byId("ReservationNumber").setText(myData.ReservationNumber);
			this.getView().byId("Material").setText(myData.Material);
			this.getView().byId("MaterialText").setText(myData.MaterialText);
			this.getView().byId("ProductionPlant").setText(myData.ProductionPlant);
			this.getView().byId("MrpController").setText(myData.MrpController);
			this.getView().byId("Unit").setText(myData.Unit);
			this.getView().byId("SystemStatus").setText(myData.SystemStatus);
			this.getView().byId("SchedReleaseDate").setText(myData.SchedReleaseDate);
			this.getView().byId("ActualReleaseDate").setText(myData.ActualReleaseDate);
			this.getView().byId("FinishDate").setText(myData.FinishDate);
			this.getView().byId("StartDate").setText(myData.StartDate);
			this.getView().byId("ProductionFinishDate").setText(myData.ProductionFinishDate);
			this.getView().byId("ProductionStartDate").setText(myData.ProductionStartDate);
			
		},
			
		onBack : function(){
				//var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);}
				else{
					window.console.log("else");
				}
				
		}

	});

});