sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/m/Popover",
	"sap/m/Button"
], function(Controller, MessageToast,Popover,Button) {
	"use strict";

	return Controller.extend("hariShopFloor.controller.dashboardSF", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf hariShopFloor.view.dashboardSF
		 */
		onInit: function() {
			
			this.detail();
		},
		detail:function(){
			var sModel = sap.ui.getCore().getModel("empInfo");
			var myData = sModel.getData();
			window.console.log(myData);
			this.getView().byId("user-btn").setText(myData.Name);
		},
		_getDialog: function() {
			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("hariShopFloor.view.Fragments.monthFrag", this);
				this.getView().addDependent(this._oDialog);
			}
			return this._oDialog;
		},
		display_frag: function(data) {
			this._getDialog().open();
			sap.ui.getCore().byId("monthtype").setText(data);
		},
		onCloseDialog: function() {
			this._oDialog.close();
		},
		//Year Fragment
		_getDialog1: function() {
			if (!this._oDialog1) {
				this._oDialog1 = sap.ui.xmlfragment("hariShopFloor.view.Fragments.yearFrag", this);
				this.getView().addDependent(this._oDialog1);
			}
			return this._oDialog1;
		},
		display_frag1: function(data) {
			this._getDialog1().open();
			sap.ui.getCore().byId("yeartype").setText(data);
		},
		onCloseDialog1: function() {
			this._oDialog1.close();
		},

		monthpressPlan: function() {
			MessageToast.show("Pressed");
			this.display_frag("Plan Order");

		},
		monthpressPro: function() {
			MessageToast.show("Pressed");
			this.display_frag("Production Order");

		},
		yearpressPlan: function() {
			MessageToast.show("Pressed");
			this.display_frag1("Plan Order");

		},
		yearpressPro: function() {
			MessageToast.show("Pressed");
			this.display_frag1("Production Order");

		},
		onMonthSelect: function() {
			MessageToast.show("Select Pressed");
			
			var selectItem = sap.ui.getCore().byId("month");
			window.console.log(selectItem);
			var month = selectItem.getSelectedItem()["mProperties"].key;
			window.console.log(month);
			MessageToast.show(month);
			
			var	selectYear = sap.ui.getCore().byId("month_year");
			window.console.log(selectYear);
			
			var monthyear = selectYear.getSelectedItem()["mProperties"].key;
			window.console.log(monthyear);
			MessageToast.show(monthyear);
			
			var type = sap.ui.getCore().byId("monthtype").getText();
			window.console.log(type);
			
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			if (type === "Plan Order") {
				oRouter.navTo("plan", {
					month: month,
					year : monthyear
				});
			} else if (type === "Production Order") {
				oRouter.navTo("pro", {
					month: month,
					year : monthyear
				});
			}
		},

		onYearSelect: function() {
			MessageToast.show("Select Pressed");
			
			var s1 = sap.ui.getCore().byId("year").getDateValue();
			window.console.log(s1);
			
			var year = s1.getFullYear();
			window.console.log(year);
			
			var type = sap.ui.getCore().byId("yeartype").getText();
			window.console.log(type);
			
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			
			if (type === "Plan Order") {
				oRouter.navTo("plan", {
					month: "year",
					year : year
					
				});
			} else if (type === "Production Order") {
				oRouter.navTo("pro", {
					month: "year",
					year : year
				});
			}
		},
		onHandler: function(event) {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			var logout = new Button({
				text: 'Logout',
				type: sap.m.ButtonType.Transparent,
				press: function() {
					window.console.log("Logout function");
					oRouter.navTo("");
				}
			});
			var popover = new Popover({
				showHeader: false,
				placement: sap.m.PlacementType.Bottom,
				content: [logout]
			}).addStyleClass('sapMOTAPopover sapTntToolHeaderPopover');

			popover.openBy(event.getSource());
		}


	});

});