sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter"
], function(Controller, JSONModel, Filter, FilterOperator, Sorter) {
	"use strict";

	return Controller.extend("hariShopFloor.controller.productOrderlist", {

		onInit: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("pro").attachPatternMatched(this._onObjectMatched, this);
		},
		_onObjectMatched: function(oEvent) {
			var oArgs;
			oArgs = oEvent.getParameter("arguments");
			var month = oArgs.month;
			var year = oArgs.year;

			this.fillData(month, year);

		},
			fillData: function(omonth,oyear) {

			var surl = "/sap/opu/odata/sap/ZPP_ODATA_HP_SRV/";
			var isMonth = "true";
			var oModel = new sap.ui.model.odata.ODataModel(surl, true);
			//Local var to loopitems
			var ooModel = new JSONModel();
			var aMonth = [];

			if (omonth === "year") {
				//this.getView().byId("planord").setText("Year" + oyear);
				isMonth = "false";
			} else {
				//this.getView().byId("planord").setText("Month" + omonth);
				isMonth = "true";
			}

			// entity name
			oModel.read("ZHP_PROD_ORD_LSTSet?$filter=Plant eq '0001' and MrpCntrl eq '001'", {
				context: null,
				urlParameters: null,
				async: false,
				success: function(oData, oResponse) {
					for (var i = 0; i < oData.results.length; i++) {
						var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
							pattern: "dd-MM-yyyy"
						});
						var dateStr = dateFormat.format(new Date(oData.results[i].StartDate));
						oData.results[i].StartDate = dateStr;
						//window.console.log(dateStr.split('/'));
						if (isMonth === "true") {
							if (dateStr.split('-')[1] === omonth  && dateStr.split('-')[2] === oyear) {
								aMonth.push(oData.results[i]);
							}
						} else if (isMonth === "false") {
							if (dateStr.split('-')[2] === oyear) {
								aMonth.push(oData.results[i]);
							}
						}
						dateStr = dateFormat.format(new Date(oData.results[i].FinishDate));
						oData.results[i].FinishDate = dateStr;
					}
					//window.console.log("OData values:");
					window.console.log(oData);
					//window.console.log("OModel Value");
					//window.console.log(ooModel.getData(oData));
					window.console.log(aMonth);
					ooModel.setData(aMonth);
				}

			});

			this.getView().setModel(ooModel, "productValue");
			
			this.mGroupFunctions = {
				SupplierName: function(oContext) {
					var name = oContext.getProperty("productValue>OrderStartDate");
					return {
						key: name,
						text: name
					};
				},
				Price: function(oContext) {
					var type = oContext.getProperty("productValue>OrderType");
					//var currencyCode = oContext.getProperty("CurrencyCode");
					var key, text;
					if (type === "PP01") {
						key = "PP01";
						text = "PP01 ";
					} else if (type === "PP04") {
						key = "PP04";
						text = "PP04";
					} 
					return {
						key: key,
						text: text
					};
				}
			};
		},
			onFilterButtonClick: function() {

			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("hariShopFloor.view.Fragments.filterdialogProd", this);
			}
			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);
			this._oDialog.open();
		},
		onExit: function() {
			if (this._oDialog) {
				this._oDialog.destroy();
			}
		},
		handleConfirm: function(oEvent) {

			var oView = this.getView();
			var oTable = oView.byId("productTable");

			var mParams = oEvent.getParameters();
			window.console.log(mParams);
			var oBinding = oTable.getBinding("items");
			window.console.log(oBinding);
			// apply sorter to binding
			// (grouping comes before sorting)
			var sPath;
			var bDescending;
			var vGroup;

			var aSorters = [];
			if (mParams.groupItem) {
				 sPath = mParams.groupItem.getKey();
				 bDescending = mParams.groupDescending;
				 vGroup = this.mGroupFunctions[sPath];
				aSorters.push(new sap.ui.model.Sorter(sPath, bDescending, vGroup));
				window.console.log("hi");
			}

		
			sPath = mParams.sortItem.getKey();
			window.console.log(sPath);
			bDescending = mParams.sortDescending;
			window.console.log(bDescending);
			aSorters.push(new Sorter(sPath, bDescending));

			window.console.log(aSorters);
			oBinding.sort(aSorters);
			window.console.log("skipped");

			// apply filters to binding
			var aFilters = [];
			jQuery.each(mParams.filterItems, function(i, oItem) {
				var aSplit = oItem.getKey().split("__");
				var sId = aSplit[0];
				var sValue = aSplit[1];
				//(new Filter("Orderid", FilterOperator.Contains, sQuery));
				window.console.log(sId, sValue);
				var oFilter = new Filter(sId, FilterOperator.Contains, sValue);
				aFilters.push(oFilter);
			});
			oBinding.filter(aFilters);
			window.console.log("last");
			window.console.log(oBinding);

			// update filter bar
			//oView.byId("vsdFilterBar").setVisible(aFilters.length > 0);
			//oView.byId("vsdFilterLabel").setText(mParams.filterString);
		},
		onSearch:function(oEvent){
			var aFilter = [];
			//var sQuery = oEvent.getParameter("query");
			var sQuery = oEvent.getSource().getValue();
			window.console.log(sQuery);
			if (sQuery && sQuery.length > 0) {
				aFilter.push(new Filter("OrderNumber", FilterOperator.Contains, sQuery));
			}
			// filter binding
			window.console.log(aFilter);
			var oList = this.getView().byId("productTable");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilter, "Application");
		},
		onRowSelect: function(oEvent) {
			window.console.log("row select");
			var oTabModelData = this.getView().byId("productTable").getModel("productValue");
			//	window.console.log(oTabModelData);
			var index = this.getView().byId("productTable")._aSelectedPaths[0].split("/")[1];
			window.console.log(index);
			window.console.log("All Rows");
			var allRows = oTabModelData.getProperty("/");
			window.console.log(allRows);
			window.console.log("Single result");
			//window.console.log(oTabModelData.getProperty("/").results[index]);
			var data = allRows[index];
			window.console.log(data.OrderNumber);

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("prodet", {
				prodOrd : data.OrderNumber
			});

		},
		onBack: function(){
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("dashboard");
		}

	});

});