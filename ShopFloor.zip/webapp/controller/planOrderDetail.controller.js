sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History"
], function(Controller,History) {
	"use strict";

	return Controller.extend("hariShopFloor.controller.planOrderDetail", {

		onInit: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("plandet").attachPatternMatched(this._onObjectMatched, this);
		},
		_onObjectMatched: function(oEvent) {
			var oArgs;
			var myData;
			oArgs = oEvent.getParameter("arguments");
			var planOrderNo = oArgs.planOrd;
			window.console.log(planOrderNo + "From details");

			var surl = "/sap/opu/odata/sap/ZPP_ODATA_HP_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(surl, true);
			//Local var to loopitems
			// entity name

			oModel.read("ZHP_PLAN_ORD_DETSet('" + planOrderNo + "')", {
				context: null,
				urlParameters: null,
				async: false,
				success: function(oData, oResponse) {
					window.console.log("OData values:");
					window.console.log(oData,oResponse);
						
						var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
							pattern: "MMM dd, yyyy "
						});
						var dateStr = dateFormat.format(new Date(oData.OrderStartDate));
						oData.OrderStartDate = dateStr;
						dateStr = dateFormat.format(new Date(oData.OrderFinDate));
						oData.OrderFinDate = dateStr;
						dateStr = dateFormat.format(new Date(oData.PlanOpenDate));
						oData.PlanOpenDate = dateStr;
						
					myData = oData;
				}
			});
			window.console.log(myData);
			this.getView().byId("PlannedorderNum").setText(myData.PlannedorderNum);
			this.getView().byId("Material").setText(myData.Material);
			this.getView().byId("OrderType").setText(myData.OrderType);
			this.getView().byId("PlanPlant").setText(myData.PlanPlant);
			this.getView().byId("ProdPlant").setText(myData.ProdPlant);
			this.getView().byId("MrpController").setText(myData.MrpController);
			this.getView().byId("ProcurementType").setText(myData.ProcurementType);
			this.getView().byId("SpecialprocType").setText(myData.SpecialprocType);
			this.getView().byId("TotalPlordQty").setText(myData.TotalPlordQty);
			this.getView().byId("OrderStartDate").setText(myData.OrderStartDate);
			this.getView().byId("OrderFinDate").setText(myData.OrderFinDate);
			this.getView().byId("PlanOpenDate").setText(myData.PlanOpenDate);
			
		},
			onBack : function(){
				//var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);}
				else{
					window.console.log("else");
				}
				
		}

	});

});