sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/Popover",
	"sap/m/Button",
	"sap/m/library",
	"jquery.sap.global",
	"sap/ui/core/Fragment",
	"sap/ui/model/json/JSONModel"
], function(Controller, Popover, Button, library, jQuery, Fragment, JSONModel) {
	"use strict";

	return Controller.extend("hariMaintenance_Portal.controller.maint_dashboard", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf hariMaintenance_Portal.view.maint_dashboard
		 */
		oEmployeeModel: new JSONModel(),
		onInit: function() {
			var sModel = sap.ui.getCore().getModel("empInfo");
			var myData = sModel.getData();
			window.console.log(myData);
			this.getView().byId("user-btn").setText(myData.Name);
			var mEmployeeData = {
				pages: [{
					header: "Employee Info",
					icon: "sap-icon://customer",
					title: myData.Name,
					description: myData.Department,
						groups: [
							{
								heading: "",
								elements: [
									{
										label: "Plan Group",
										value:  myData.PlanGrp,
										elementType: sap.m.QuickViewGroupElementType.pageLink,
										pageLinkId: "contactPage"
									},
									{
										label: "Plant",
										value:  myData.Plant,
										elementType: sap.m.QuickViewGroupElementType.pageLink,
										pageLinkId: "contactPage"
									}
								]
							}
						]
				}]
			};
	
			this.oEmployeeModel.setData(mEmployeeData);
		},

		onSideNavButtonPress: function() {
			var viewId = this.getView().getId();
			var toolPage = sap.ui.getCore().byId(viewId + "--toolPage");
			var sideExpanded = toolPage.getSideExpanded();

			this._setToggleButtonTooltip(sideExpanded);

			toolPage.setSideExpanded(!toolPage.getSideExpanded());
		},

		_setToggleButtonTooltip: function(bLarge) {
			var toggleButton = this.getView().byId('sideNavigationToggleButton');
			if (bLarge) {
				toggleButton.setTooltip('Large Size Navigation');
			} else {
				toggleButton.setTooltip('Small Size Navigation');
			}
		},
		onItemSelect: function(oEvent) {
			var oItem = oEvent.getParameter("item");
			window.console.log(oItem.getKey());
			window.console.log(this.getView().createId(oItem.getKey()));
			this.byId("pageContainer").to(this.getView().createId(oItem.getKey()));
		},
		onProfile: function() {
			window.console.log("Profile Clicked");
		},
		onHandler: function(event) {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			var logout = new Button({
				text: 'Logout',
				type: sap.m.ButtonType.Transparent,
				press: function() {
					window.console.log("Logout function");
					oRouter.navTo("mainLogin", true);
				}
			});
			var popover = new Popover({
				showHeader: false,
				placement: sap.m.PlacementType.Bottom,
				content: [logout]
			}).addStyleClass('sapMOTAPopover sapTntToolHeaderPopover');

			popover.openBy(event.getSource());
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf hariMaintenance_Portal.view.maint_dashboard
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf hariMaintenance_Portal.view.maint_dashboard
		 */
		onAfterRendering: function() {
			var oButton = this.getView().byId('emp_detail');
			oButton.$().attr('aria-haspopup', true);
		},
		openQuickView: function(oEvent, oModel) {
			this.createPopover();

			this._oQuickView.setModel(oModel);

			// delay because addDependent will do a async rerendering and the actionSheet will immediately close without it.
			var oButton = oEvent.getSource();
			jQuery.sap.delayedCall(0, this, function() {
				this._oQuickView.openBy(oButton);
			});
		},
		handleEmployeeQuickViewPress: function(oEvent) {
			this.openQuickView(oEvent, this.oEmployeeModel);
		},
		createPopover: function() {
			if (this._oQuickView) {
				this._oQuickView.destroy();
			}

			this._oQuickView = sap.ui.xmlfragment("hariMaintenance_Portal.view.Fragments.employeeFragment", this);
			this.getView().addDependent(this._oQuickView);
		},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf hariMaintenance_Portal.view.maint_dashboard
		 */
		onExit: function() {
			if (this._oQuickView) {
				this._oQuickView.destroy();
			}
		}

	});

});