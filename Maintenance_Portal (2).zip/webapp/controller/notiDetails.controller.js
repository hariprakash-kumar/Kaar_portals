sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function(Controller, JSONModel) {
	"use strict";

	return Controller.extend("hariMaintenance_Portal.controller.notiDetails", {

		onInit: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("noti").attachPatternMatched(this._onObjectMatched, this);
			window.console.log("init last");
		},
		_onObjectMatched: function(oEvent) {
			var oArgs;
			var myData;
			oArgs = oEvent.getParameter("arguments");
			var resultid = oArgs.notif_id;
			window.console.log(resultid);
			///sap/opu/odata/sap/ZPM_ODATA_HP_SRV/ZHP_NOTIF_DETAILSet('10000091')
			window.console.log("object last");
			var surl = "/sap/opu/odata/sap/ZPM_ODATA_HP_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(surl, true);
			//Local var to loopitems
			// entity name

			oModel.read("ZHP_NOTIF_DETAILSet('" + resultid + "')", {
				context: null,
				urlParameters: null,
				async: false,
				success: function(oData, oResponse) {
					window.console.log("OData values:");
					window.console.log(oData);
					myData = oData;
				}
			});
			window.console.log(myData);
			this.getView().byId("NotifNo").setText(myData.NotifNo);
			this.getView().byId("NotifType").setText(myData.NotifType);
			this.getView().byId("ShortText").setText(myData.ShortText);
			this.getView().byId("Priority").setText(myData.Priority);
			this.getView().byId("Priotype").setText(myData.Priotype);
			this.getView().byId("Plangroup").setText(myData.Plangroup);
			this.getView().byId("LocAcc").setText(myData.LocAcc);
			this.getView().byId("Equipment").setText(myData.Equipment);
			this.getView().byId("CreatedBy").setText(myData.CreatedBy);
			this.getView().byId("Orderid").setText(myData.Orderid);
			this.getView().byId("PmWkctr").setText(myData.PmWkctr);
			this.getView().byId("Planplant").setText(myData.Planplant);

		},
		onBack: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("mainDash");
		}

	});

});