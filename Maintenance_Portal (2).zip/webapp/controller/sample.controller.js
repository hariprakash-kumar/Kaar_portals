sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter",
	"sap/m/MessageToast"

], function(Controller, JSONModel, Filter, FilterOperator, Sorter, MessageToast) {
	"use strict";

	return Controller.extend("hariMaintenance_Portal.controller.sample", {

		onInit: function() {

			var sModel = sap.ui.getCore().getModel("empInfo");
			var myData = sModel.getData();
			window.console.log(myData);
			window.console.log("Plant", myData.Plant);
			var plangrp = myData.PlanGrp;
			var plant = myData.Plant;

			var surl = "/sap/opu/odata/sap/ZPM_ODATA_HP_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(surl, true);
			//Local var to loopitems
			var ooModel = new JSONModel();
			// entity name
			oModel.read("ZHP_NOTIF_LISTSet?$filter=PlanGrp eq '" + plangrp + "'and Plant eq '" + plant + "' and Date eq datetime'2022-04-06T00:00:00'", {
				context: null,
				urlParameters: null,
				async: false,
				success: function(oData, oResponse) {
					
						for (var i = 0; i < oData.results.length; i++) {
						var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
							pattern: "MMM dd, yyyy "
						});
						var dateStr = dateFormat.format(new Date(oData.results[i].Startdate));
						oData.results[i].Startdate = dateStr;
						dateStr = dateFormat.format(new Date(oData.results[i].Enddate));
						oData.results[i].Enddate = dateStr;
						}
					
					window.console.log("OData values:");
					window.console.log(oData);
					window.console.log("OModel Value");
					ooModel.setData(oData);
					//.split(" ").slice(1,4).join(" ")
					var len = oData.results.length;
					window.console.log(len);
					var res = oData.results[0]['Startdate'];
					window.console.log("result",res);
					//window.console.log(ooModel.getData(oData));
				}

			});
			this._oDialog = sap.ui.xmlfragment("hariMaintenance_Portal.view.Fragments.filterDialog", this);
			this.getView().setModel(ooModel, "itemValue");
			//window.console.log("Get View hari " + this.getView("hariRouting_Samp
			// window.console.log("Get View  " + this.getView());
			// window.console.log("Sales init ends");

		},
		//Filter fragment method
		onFilterButtonClick: function() {
			window.console.log("Filter btn");
			var val = this._oDialog;
			window.console.log(val);
			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("hariMaintenance_Portal.view.Fragments.filterDialog", this);
			}
			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);
			this._oDialog.open();
		},
		handleConfirm: function(oEvent) {

			var oView = this.getView();
			var oTable = oView.byId("itTable");

			var mParams = oEvent.getParameters();
			window.console.log(mParams);
			var oBinding = oTable.getBinding("items");
			window.console.log(oBinding);
			// apply sorter to binding
			// (grouping comes before sorting)
			var sPath;
			var bDescending;
			//var vGroup;
			var aSorters = [];
			// if (mParams.groupItem) {
			// 	sPath = mParams.groupItem.getKey();
			// 	bDescending = mParams.groupDescending;
			// 	vGroup = this.mGroupFunctions[sPath];
			// 	aSorters.push(new Sorter(sPath, bDescending, vGroup));
			// }
			sPath = mParams.sortItem.getKey();
			window.console.log(sPath);
			bDescending = mParams.sortDescending;
			window.console.log(bDescending);
			aSorters.push(new Sorter(sPath, bDescending));

			window.console.log(aSorters);
			oBinding.sort(aSorters);
			window.console.log("skipped");

			// apply filters to binding
			var aFilters = [];
			jQuery.each(mParams.filterItems, function(i, oItem) {
				var aSplit = oItem.getKey().split("__");
				var sId = aSplit[0];
				var sValue = aSplit[1];
				//(new Filter("Orderid", FilterOperator.Contains, sQuery));
				window.console.log(sId, sValue);
				var oFilter = new Filter(sId, FilterOperator.Contains, sValue);
				aFilters.push(oFilter);
			});
			oBinding.filter(aFilters);
			window.console.log("last");
			window.console.log(oBinding);

			// update filter bar
			//oView.byId("vsdFilterBar").setVisible(aFilters.length > 0);
			//oView.byId("vsdFilterLabel").setText(mParams.filterString);
		},
		onExit: function() {
			if (this._oDialog) {
				this._oDialog.destroy();
			}
		},
		//search field
		onFilter: function(oEvent) {
			// build filter array
			var aFilter = [];
			//var sQuery = oEvent.getParameter("query");
			var sQuery = oEvent.getSource().getValue();
			window.console.log(sQuery);
			if (sQuery && sQuery.length > 0) {
				aFilter.push(new Filter("Notificat", FilterOperator.Contains, sQuery));
			}
			// filter binding
			window.console.log(aFilter);
			var oList = this.getView().byId("itTable");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilter, "Application");
		},
		// _getDialog: function(frag, data) {

		// 	window.console.log("Link viz");
		// 	window.console.log(this._oDialog);

		// 	if (this._oDialog) {
		// 		this._oDialog = sap.ui.xmlfragment(frag, this);
		// 		this.getView().addDependent(this._oDialog);
		// 		window.console.log("get dialog" + data);
		// 	}
		// 	sap.ui.getCore().byId("create_wo").setText(data);
		// 	return this._oDialog;
		// },
		// display_frag: function(data) {
		// 	this._getDialog("hariMaintenance_Portal.view.Fragments.workOrderCreateFrag", data).open();
		// },
		// table row select
		onRowSelect: function(oEvent) {
			window.console.log("row select");

			var oTabModelData = this.getView().byId("itTable").getModel("itemValue");
			//	window.console.log(oTabModelData);
			var index = this.getView().byId("itTable")._aSelectedPaths[0].split("/")[2];
			window.console.log(index);
			var allRows = oTabModelData.getProperty("/");
			window.console.log(allRows);
			window.console.log("Single result");
			//window.console.log(oTabModelData.getProperty("/").results[index]);
			var data = allRows.results[index];
			window.console.log(data.Notificat);

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("noti", {
				notif_id: data.Notificat
			});

		},
		onCloseDialog: function() {
			this._oDialog.destroy();
		},
		// cell select
		onIcon: function(oEvent) {
			window.console.log("Icon Clicked");
		//	var cellName = oEvent.getSource().getParent().getCells()[0].getText();
		//	window.console.log(cellName);
		//	this.display_frag(cellName);

		},
		onCreateWO: function(oEvent) {
			var msg = "This Feature is not enabled";
			window.console.log(msg);
			MessageToast.show(msg);
		}
	});

});