sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter"
], function(Controller, JSONModel, Filter, FilterOperator,Sorter) {
	"use strict";

	return Controller.extend("hariMaintenance_Portal.controller.maint_workorder", {

		onInit: function() {
			
			var sModel = sap.ui.getCore().getModel("empInfo");
			var myData = sModel.getData();
			window.console.log(myData);
			window.console.log("Plant", myData.Plant);
			var plangrp = myData.PlanGrp;
			var plant = myData.Plant;

			var oView = this.getView();
			var surl = "/sap/opu/odata/sap/ZPM_ODATA_HP_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(surl, true);
			//Local var to loopitems
			var ooModel = new JSONModel();
			// entity name
			oModel.read("ZHP_WORKORDERLISTSet?$filter=Plangroup eq '" + plangrp + "' and Plant eq '" + plant + "'", {
				context: null,
				urlParameters: null,
				async: false,
				success: function(oData, oResponse) {
					window.console.log("OData wo values:");
					window.console.log(oData);
					window.console.log("OModel wo Value");
					ooModel.setData(oData);
					//.split(" ").slice(1,4).join(" ")

				}

			});
			this._oDialog = sap.ui.xmlfragment("hariMaintenance_Portal.view.Fragments.filterDialog", this);
			this.getView().setModel(ooModel, "woValue");

			window.console.log(oModel);
			oView.setModel(oModel);
		},
		_getDialog1: function() {
			if (!this._oDialog1) {
				this._oDialog1 = sap.ui.xmlfragment("hariMaintenance_Portal.view.Fragments.workOrderDetailFrag", this);
			}
			return this._oDialog1;
		},
		display_frag: function(data) {
			this._getDialog1().open();
		
			sap.ui.getCore().byId("forder_id").setValue(data.Orderid);
			sap.ui.getCore().byId("ford_type").setValue(data.OrderType);
			sap.ui.getCore().byId("ford_plan").setValue(data.Planplant);
			sap.ui.getCore().byId("ford_wc").setValue(data.MnWkCtr);
			sap.ui.getCore().byId("ford_plant").setValue(data.Plant);
			sap.ui.getCore().byId("ford_wcid").setValue(data.MnWkctrId);
			sap.ui.getCore().byId("ford_eqi").setValue(data.Equipment);

		},
		//Filter fragment method
		onFilterButtonClick: function() {
			window.console.log("Filter btn");
			var val = this._oDialog2;
			window.console.log(val);
			if (!this._oDialog2) {
				this._oDialog2 = sap.ui.xmlfragment("hariMaintenance_Portal.view.Fragments.workOrderCreateFrag", this);
			}
			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog2);
			this._oDialog2.open();
		},
		handleConfirm: function(oEvent) {

			var oView = this.getView();
			var oTable = oView.byId("woTable");

			var mParams = oEvent.getParameters();
			window.console.log(mParams);
			var oBinding = oTable.getBinding("items");
			window.console.log(oBinding);
			// apply sorter to binding
			// (grouping comes before sorting)
			var sPath;
			var bDescending;
			//var vGroup;
			var aSorters = [];
			// if (mParams.groupItem) {
			// 	sPath = mParams.groupItem.getKey();
			// 	bDescending = mParams.groupDescending;
			// 	vGroup = this.mGroupFunctions[sPath];
			// 	aSorters.push(new Sorter(sPath, bDescending, vGroup));
			// }
			sPath = mParams.sortItem.getKey();
			window.console.log(sPath);
			bDescending = mParams.sortDescending;
			window.console.log(bDescending);
			aSorters.push(new Sorter(sPath, bDescending));

			window.console.log(aSorters);
			oBinding.sort(aSorters);
			window.console.log("skipped");

			// apply filters to binding
			var aFilters = [];
			jQuery.each(mParams.filterItems, function(i, oItem) {
				var aSplit = oItem.getKey().split("__");
				var sId = aSplit[0];
				var sValue = aSplit[1];
				//(new Filter("Orderid", FilterOperator.Contains, sQuery));
				window.console.log(sId, sValue);
				var oFilter = new Filter(sId, FilterOperator.Contains, sValue);
				aFilters.push(oFilter);
			});
			oBinding.filter(aFilters);
			window.console.log("last");
			window.console.log(oBinding);
		},
		onExit: function() {
			if (this._oDialog2) {
				this._oDialog2.destroy();
			}
		},
		onRowSelectwo: function(oEvent) {
			window.console.log("row select");
			var s = 0;
			var oTabModelData = this.getView().byId("woTable").getModel("woValue");
			//	window.console.log(oTabModelData);
			var index = this.getView().byId("woTable")._aSelectedPaths[0].split("/")[2];
			window.console.log(index);
			var allRows = oTabModelData.getProperty("/");
			window.console.log(allRows);
			window.console.log("Single result");
			//window.console.log(oTabModelData.getProperty("/").results[index]);
			var data = allRows.results[index];
			var wo_id = data.Orderid;

			var surl = "/sap/opu/odata/sap/ZPM_ODATA_HP_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(surl, true);
			//Local var to loopitems
			var ooModel = new JSONModel();
			// entity name
			oModel.read("ZHP_WORKORDERDETAILSet('" + wo_id + "')", {

				context: null,
				urlParameters: null,
				async: false,
				success: function(oData, oResponse) {
					// window.console.log("OData values:");
					// window.console.log(oData.Number);
					ooModel = oData;
					s = 1;
				}

			});
			window.console.log(ooModel);
			window.console.log(s);
			this.display_frag(ooModel);

		},

		onCloseDialog: function() {
			this._oDialog1.close();
		},
		//search field
		onwoFilter: function(oEvent) {
			// build filter array
			var aFilter = [];
			//var sQuery = oEvent.getParameter("query");
			var sQuery = oEvent.getSource().getValue();
			window.console.log(sQuery);
			if (sQuery && sQuery.length > 0) {
				aFilter.push(new Filter("Orderid", FilterOperator.Contains, sQuery));
			}
			// filter binding
			window.console.log(aFilter);
			var oList = this.getView().byId("woTable");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilter, "Application");
		}

	});

});