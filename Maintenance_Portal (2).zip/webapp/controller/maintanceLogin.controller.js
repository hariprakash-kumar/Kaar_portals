sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
], function(Controller, MessageBox) {
	"use strict";

	return Controller.extend("hariMaintenance_Portal.controller.maintanceLogin", {
		onInit: function() {
		},
		onLogin: function() {

			var empId = this.getView().byId("emp_id").getValue();
			var emPass = this.getView().byId("emp_pass").getValue();
			// OData Model
			if (empId !== "" && emPass !== "") {
				// service base url
				var surl = "/sap/opu/odata/sap/ZPM_ODATA_HP_SRV/"; 
				var oModel = new sap.ui.model.odata.ODataModel(surl, true);
				// uri
				var uri = "Password='" + emPass + "',UserId='" + empId + "'";
				var status;
				// var cusId;
				var empName;
				var department;
				var plant;
				var plantgrp;
				
				oModel.read("ZPM_LOGIN_HPSet(" + uri + ")", {
					context: null,
					urlParameters: null,
					async: false,
					success: function(oData, oResponse) {
						window.console.log(oData);
						status = oData.Message;
						empName = oData.Name;
						department = oData.Depart;
						plant = oData.Plant;
						plantgrp = oData.PlanGrp;
					
					}
				});
					var detail = {
					"Name":empName,
					"Department":department,
					"Plant":plant,
					"PlanGrp":plantgrp
				};
				var sampleModel = new sap.ui.model.json.JSONModel(detail);
				sap.ui.getCore().setModel(sampleModel, 'empInfo');
				
				if (status === "Sucess") {
					window.console.log("Sucess");
					var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					oRouter.navTo("mainDash");
				} else if (status === "Incorrect Password") {
					MessageBox.warning("Password Incorrect");
				} else if (status === "User Not Found") {
					window.console.log("User not Found");
					MessageBox.error("The User Id " + empId + " not Found");
				} else {
					window.console.log("Other error");
				}
			} else {
				MessageBox.alert("Fill all the fields");
			}
		}
	});

});