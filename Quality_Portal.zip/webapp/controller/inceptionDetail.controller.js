sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function(Controller,JSONModel) {
	"use strict";

	return Controller.extend("hariQuality_Portal.controller.inceptionDetail", {

			onInit: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("inspDet").attachPatternMatched(this._onObjectMatched, this);
		},
		_onObjectMatched: function(oEvent) {
			var oArgs;
			var jsonModel;
			oArgs = oEvent.getParameter("arguments");
			var lotNo = oArgs.lot;
			window.console.log(lotNo);

			var surl = "/sap/opu/odata/sap/ZQM_ODATA_HP_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(surl, true);

			var operationModel = new JSONModel();
			//var systemModel = new JSONModel();
			//Local var to loopitems
			// entity name

			// /sap/opu/odata/sap/ZQM_ODATA_HP_SRV/ 890000000000')
			oModel.read("ZHP_INCEPTION_LOT_DETAILSet('" + lotNo + "')", {
				context: null,
				urlParameters: null,
				async: false,
				success: function(oData, oResponse) {
					window.console.log("OData values General Data");
					window.console.log(oData);
					jsonModel= new sap.ui.model.json.JSONModel(oData);
				}
			});

			this.getView().setModel(operationModel, "opeartionValue");
			//this.getView().setModel(systemModel, "statusValue");
			this.getView().setModel(jsonModel);
			this.getView().byId("lotNumber").setText(lotNo);
			//this.getView().byId("operationId").setText("Operation List of " + lotNo);

		},
		onBack: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("lotlist");
		},
		onRowSelect: function(oEvent) {
				window.console.log("row select");
				var oTabModelData = this.getView().byId("opeartionTable").getModel("opeartionValue");
				//	window.console.log(oTabModelData);
				var index = this.getView().byId("opeartionTable")._aSelectedPaths[0].split("/")[2];
				window.console.log(index);
				var allRows = oTabModelData.getProperty("/");
				window.console.log(allRows);
				window.console.log("Single result");
				//window.console.log(oTabModelData.getProperty("/").results[index]);
				var data = allRows.results[index];
				window.console.log(data.Insplot);
				window.console.log(data.Inspoper);
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("detail", {
					lot: data.Insplot,
					opno : data.Inspoper
					
				});
				// var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				// oRouter.navTo("operation", {
				// 	lot: data.Insplot
				// });

			}

	});

});