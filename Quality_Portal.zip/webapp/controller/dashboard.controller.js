sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/Popover",
	"sap/m/Button"
], function(Controller,JSONModel, Popover, Button) {
	"use strict";

	return Controller.extend("hariQuality_Portal.controller.dashboard", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf hariQuality_Portal.view.dashboard
		 */
		 oEmployeeModel: new JSONModel(),
		onInit: function() {
			
			this.detail();
		},
		detail: function() {
			var sModel = sap.ui.getCore().getModel("empInfo");
			var myData = sModel.getData();
			window.console.log(myData);
			this.getView().byId("user-btn").setText(myData.Name);
			
			var mEmployeeData = {
				pages: [{
					header: "Employee Info",
					icon: "sap-icon://customer",
					title: myData.Name,
					description: myData.Department,
						groups: [
							{
								heading: "",
								elements: [
									{
										label: "Plant",
										value:  myData.Plant,
										elementType: sap.m.QuickViewGroupElementType.pageLink,
										pageLinkId: "contactPage"
									}
								]
							}
						]
				}]
			};
	
			this.oEmployeeModel.setData(mEmployeeData);
		},
		onLotClick: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("lotlist");
		},
		onResClick: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("resrec");
		},
		onUDClick: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("usage");
		},
		onHandler: function(event) {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			var logout = new Button({
				text: 'Logout',
				type: sap.m.ButtonType.Transparent,
				press: function() {
					window.console.log("Logout function");
					oRouter.navTo("");
				}
			});
			var popover = new Popover({
				showHeader: false,
				placement: sap.m.PlacementType.Bottom,
				content: [logout]
			}).addStyleClass('sapMOTAPopover sapTntToolHeaderPopover');

			popover.openBy(event.getSource());
		},
		
		
		// Employee Profile 
		onAfterRendering: function() {
			var oButton = this.getView().byId('emp_detail');
			oButton.$().attr('aria-haspopup', true);
		},
		openQuickView: function(oEvent, oModel) {
			this.createPopover();

			this._oQuickView.setModel(oModel);

			// delay because addDependent will do a async rerendering and the actionSheet will immediately close without it.
			var oButton = oEvent.getSource();
			jQuery.sap.delayedCall(0, this, function() {
				this._oQuickView.openBy(oButton);
			});
		},
		handleEmployeeQuickViewPress: function(oEvent) {
			this.openQuickView(oEvent, this.oEmployeeModel);
		},
		createPopover: function() {
			if (this._oQuickView) {
				this._oQuickView.destroy();
			}

			this._oQuickView = sap.ui.xmlfragment("hariQuality_Portal.view.Fragments.employeeFragment", this);
			this.getView().addDependent(this._oQuickView);
		}


	});

});