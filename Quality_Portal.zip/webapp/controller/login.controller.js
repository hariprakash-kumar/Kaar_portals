sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
], function(Controller,MessageBox) {
	"use strict";

	return Controller.extend("hariQuality_Portal.controller.login", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf hariQuality_Portal.view.login
		 */
			onInit: function() {
		
			},
				onLogin: function() {

			var empId = this.getView().byId("emp_id").getValue();
			var emPass = this.getView().byId("emp_pass").getValue();
			// OData Model
			if (empId !== "" && emPass !== "") {
				// service base url
				// ZHP_LOGIN_QMSet(Password='5',UserId='5')
				
				var surl = "/sap/opu/odata/sap/ZQM_ODATA_HP_SRV/"; 
				var oModel = new sap.ui.model.odata.ODataModel(surl, true);
				// uri
				var uri = "Password='" + emPass + "',UserId='" + empId + "'";
				var status;
				// var cusId;
				var empName;
				var department;
				var plant;
				
				oModel.read("ZHP_LOGIN_QMSet(" + uri + ")", {
					context: null,
					urlParameters: null,
					async: false,
					success: function(oData, oResponse) {
						window.console.log(oData);
						status = oData.Message;
						empName = oData.Name;
						department = oData.Designation;
						plant = oData.Plant;
					
					}
				});
					var detail = {
					"Name":empName,
					"Department":department,
					"Plant":plant
				};
				var sampleModel = new sap.ui.model.json.JSONModel(detail);
				sap.ui.getCore().setModel(sampleModel, 'empInfo');
				
				if (status === "Sucess") {
					window.console.log("Sucess");
					var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					oRouter.navTo("dashboard");
				} else if (status === "Incorrect Password") {
					MessageBox.warning("Password Incorrect");
				} else if (status === "User Not Found") {
					window.console.log("User not Found");
					MessageBox.error("The User Id " + empId + " not Found");
				} else {
					window.console.log("Other error");
				}
			} else {
				MessageBox.alert("Fill all the fields");
			}
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf hariQuality_Portal.view.login
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf hariQuality_Portal.view.login
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf hariQuality_Portal.view.login
		 */
		//	onExit: function() {
		//
		//	}

	});

});