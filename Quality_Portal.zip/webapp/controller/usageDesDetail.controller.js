sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/m/MessageToast"
], function(Controller, JSONModel, History,MessageToast) {
	"use strict";

	return Controller.extend("hariQuality_Portal.controller.usageDesDetail", {

		onInit: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("usageDet").attachPatternMatched(this._onObjectMatched, this);
		},
		_onObjectMatched: function(oEvent) {
			var oArgs;

			oArgs = oEvent.getParameter("arguments");
			var lotNo = oArgs.lot;
			var state = oArgs.state;
			window.console.log(lotNo);
			window.console.log(state);

			var surl = "/sap/opu/odata/sap/ZQM_ODATA_HP_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(surl, true);

			var udDetModel = new JSONModel();
			//var systemModel = new JSONModel();
			//Local var to loopitems
			// entity name

			oModel.read("ZHP_SYSTEM_STATUSSet?$filter=LotNumber eq '" + lotNo + "'", {
				context: null,
				urlParameters: null,
				async: false,
				success: function(oData, oResponse) {
					window.console.log("OData values result list :");
					window.console.log(oData);
					udDetModel.setData(oData);
				}
			});
			var jsonModel;
			oModel.read("ZHP_INCEPTION_LOT_DETAILSet(LotNumber='" + lotNo + "')", {
				context: null,
				urlParameters: null,
				async: false,
				success: function(oData, oResponse) {
					//window.console.log("OData values 2 entity status :");
					window.console.log(oData.length);

					var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
						pattern: "MMM dd, yyyy "
					});
					var dateStr = dateFormat.format(new Date(oData.UdRecordedOnDate));
					oData.UdRecordedOnDate = dateStr;
					oData.FormState = true;
					window.console.log(oData);
					jsonModel = new sap.ui.model.json.JSONModel(oData);

				}
			});
			if(state === "NV"){
				jsonModel['oData'].FormState = false;
				MessageToast.show("Details can't be shown for not validated lots");
			}
			window.console.log(jsonModel);
			this.getView().setModel(udDetModel, "udDetValue");
			this.getView().setModel(jsonModel);

			//this.getView().setModel(systemModel, "statusValue");
			//this.getView().byId("lotNumber").setText(lotNo);
			//this.getView().byId("operationId").setText("Operation List of " + lotNo);

		},
		onBack: function() {
			var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				window.console.log("else");
			}
		}

	});

});