sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter"
], function(Controller, JSONModel, Filter, FilterOperator, Sorter) {
	"use strict";

	return Controller.extend("hariQuality_Portal.controller.usageDesion", {

		onInit: function() {
			//ZHP_INCEPTION_LOT_LISTSet?$filter=Plant eq '0001'&$format=json
			var surl = "/sap/opu/odata/sap/ZQM_ODATA_HP_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(surl, true);
			//Local var to loopitems
			var udModel = new JSONModel();
			// entity name

			var sModel = sap.ui.getCore().getModel("empInfo");
			var myData = sModel.getData();
			window.console.log(myData.Plant);
			
			oModel.read("ZHP_USAGE_DESSet?$filter=Plant eq '"+ myData.Plant +"'", {
				context: null,
				urlParameters: null,
				async: false,
				success: function(oData, oResponse) {
					window.console.log("OData values:");
					window.console.log(oData);
					window.console.log("OModel Value");

					//window.console.log(ooModel.getData(oData));
					for (var i = 0; i < oData.results.length; i++) {
						var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
							pattern: "MMM dd, yyyy "
						});
						var dateStr = dateFormat.format(new Date(oData.results[i].UdRecordedOnDate));
						oData.results[i].UdRecordedOnDate = dateStr;
					}
					udModel.setData(oData);
					window.console.log(udModel);
				}

			});

			this.getView().setModel(udModel, "udValue");

			this.mGroupFunctions = {
				Price: function(oContext) {
					var type = oContext.getProperty("lotValue>UdStatus");
					//var currencyCode = oContext.getProperty("CurrencyCode");
					var key, text;
					if (type === "ACCEPTED") {
						key = "ACCEPTED";
						text = "ACCEPTED";
					} else if (type === "NOT VALIDATED") {
						key = "NOT VALIDATED";
						text = "NOT VALIDATED";
					} else if (type === "REJECTED") {
						key = "REJECTED";
						text = "REJECTED";
					}
					return {
						key: key,
						text: text
					};
				}
			};

		},
		onBack: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("dashboard");
		},
		formatRowHighlight: function(data) {
			if (data === 'ACCEPTED') {
				return sap.ui.core.ValueState.Success;
			} else if (data === 'REJECTED') {
				return sap.ui.core.ValueState.Error;
			} else {
				return sap.ui.core.ValueState.Warning;
			}

		},
		onClick: function(oEvent) {
			window.console.log("Hi");
		},
		onSearch: function(oEvent) {
			var aFilter = [];
			//var sQuery = oEvent.getParameter("query");
			var sQuery = oEvent.getSource().getValue();
			window.console.log(sQuery);
			if (sQuery && sQuery.length > 0) {
				aFilter.push(new Filter("Insplot", FilterOperator.Contains, sQuery));
			}
			// filter binding
			window.console.log(aFilter);
			var oList = this.getView().byId("udTable");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilter, "Application");
		},

		onFilterButtonClick: function() {

			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("hariQuality_Portal.view.Fragments.lotListFilter", this);
			}
			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);
			this._oDialog.open();
		},
		onExit: function() {
			if (this._oDialog) {
				this._oDialog.destroy();
			}
		},
		handleConfirm: function(oEvent) {

			var oView = this.getView();
			var oTable = oView.byId("udTable");

			var mParams = oEvent.getParameters();
			window.console.log(mParams);
			var oBinding = oTable.getBinding("items");
			window.console.log(oBinding);
			// apply sorter to binding
			// (grouping comes before sorting)
			var sPath;
			var bDescending;
			var vGroup;

			var aSorters = [];
			if (mParams.groupItem) {
				sPath = mParams.groupItem.getKey();
				bDescending = mParams.groupDescending;
				vGroup = this.mGroupFunctions[sPath];
				aSorters.push(new sap.ui.model.Sorter(sPath, bDescending, vGroup));
				window.console.log("hi");
			}

			sPath = mParams.sortItem.getKey();
			window.console.log(sPath);
			bDescending = mParams.sortDescending;
			window.console.log(bDescending);
			aSorters.push(new Sorter(sPath, bDescending));

			window.console.log(aSorters);
			oBinding.sort(aSorters);
			window.console.log("skipped");

			// apply filters to binding
			var aFilters = [];
			jQuery.each(mParams.filterItems, function(i, oItem) {
				var aSplit = oItem.getKey().split("__");
				var sId = aSplit[0];
				var sValue = aSplit[1];
				//(new Filter("Orderid", FilterOperator.Contains, sQuery));
				window.console.log(sId, sValue);
				var oFilter = new Filter(sId, FilterOperator.Contains, sValue);
				aFilters.push(oFilter);
			});
			oBinding.filter(aFilters);
			window.console.log("last");
			window.console.log(oBinding);

			// update filter bar
			//oView.byId("vsdFilterBar").setVisible(aFilters.length > 0);
			//oView.byId("vsdFilterLabel").setText(mParams.filterString);
		},
			onRowSelect: function(oEvent) {
			window.console.log("row select");
			var oTabModelData = this.getView().byId("udTable").getModel("udValue");
			//	window.console.log(oTabModelData);
			var index = this.getView().byId("udTable")._aSelectedPaths[0].split("/")[2];
			window.console.log(index);
			var allRows = oTabModelData.getProperty("/");
			window.console.log(allRows);
			window.console.log("Single result");
			//window.console.log(oTabModelData.getProperty("/").results[index]);
			var data = allRows.results[index];
			window.console.log(data.Insplot);
			window.console.log(data.UdStatus);
			var state;
			if(data.UdStatus === "ACCEPTED"){
				state = "A";
			}
			else if(data.UdStatus === "REJECTED"){
				state = "R";
			}
			else{
				state = "NV";
			}
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("usageDet", {
				lot: data.Insplot,
				state:state
			});

		}

	});

});