sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History"
], function(Controller,History) {
	"use strict";

	return Controller.extend("hariEHSM_Portal.controller.incidentDetail", {

		onInit: function() {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("incidentdetail").attachPatternMatched(this._onObjectMatched, this);
		},
		_onObjectMatched: function(oEvent) {
			var oArgs;
			var myData;
			oArgs = oEvent.getParameter("arguments");
			var recNo = oArgs.number;
			window.console.log(recNo + "From details");

			var surl = "/sap/opu/odata/sap/ZEHSM_ODATA_HP_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(surl, true);
			//Local var to loopitems
			// entity name ZHP_INCIDENT_DETAILSet('1')

			oModel.read("ZHP_INCIDENT_DETAILSet('" + recNo + "')", {
				context: null,
				urlParameters: null,
				async: false,
				success: function(oData, oResponse) {
					window.console.log("OData values:");
					window.console.log(oData,oResponse);
						
						var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
							pattern: "MMM dd, yyyy "
						});
						
						var dateStr = dateFormat.format(new Date(oData.Valfr));
						oData.Valfr = dateStr;
						dateStr = dateFormat.format(new Date(oData.Valto));
						oData.Valto = dateStr;
						// dateStr = dateFormat.format(new Date(oData.Evdat));
						// oData.Evdat = dateStr;
						
					myData = oData;
				}
			});
			window.console.log(myData);
			this.getView().byId("Recn").setText(myData.Recn);
			this.getView().byId("Actn").setText(myData.Actn);
			this.getView().byId("Valfr").setText(myData.Valfr);
			this.getView().byId("Valto").setText(myData.Valto);
		
			this.getView().byId("Delflg").setText(myData.Delflg);
			this.getView().byId("Parkflg").setText(myData.Parkflg);
			this.getView().byId("Ialid").setText(myData.Ialid);
			this.getView().byId("Iatype").setText(myData.Iatype);
			this.getView().byId("Iaplant").setText(myData.Iaplant);
			this.getView().byId("Objnr").setText(myData.Objnr);
			this.getView().byId("Iastatus").setText(myData.Iastatus);
			this.getView().byId("Evdesc").setText(myData.Evdesc);
			this.getView().byId("Dmtype").setText(myData.Dmtype);
			this.getView().byId("Tplnr").setText(myData.Tplnr);
			this.getView().byId("Equnr").setText(myData.Equnr);
			this.getView().byId("Eqdesc").setText(myData.Eqdesc);
			this.getView().byId("Acloc").setText(myData.Acloc);
			this.getView().byId("Aclocdesc").setText(myData.Aclocdesc);
			
		},
			onBack : function(){
				//var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				var oHistory = History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);}
				else{
					window.console.log("else");
				}
				
		}


	});

});