sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
], function(Controller,MessageBox) {
	"use strict";

	return Controller.extend("hariEHSM_Portal.controller.ehsm_login", {

		onInit: function() {
		},
		onLogin: function() {

			var empId = this.getView().byId("emp_id").getValue();
			var emPass = this.getView().byId("emp_pass").getValue();
			// OData Model (Pass='4',UserId='4')
			if (empId !== "" && emPass !== "") {
				// service base url
				var surl = "/sap/opu/odata/sap/ZEHSM_ODATA_HP_SRV/"; 
				var oModel = new sap.ui.model.odata.ODataModel(surl, true);
				// uri
				var uri = "Pass='" + emPass + "',UserId='" + empId + "'";
				var status;
				// var cusId;
				var empName;
				var department;
				var plant;
				
				
				oModel.read("ZHP_LOGIN_EHSMSet(" + uri + ")", {
					context: null,
					urlParameters: null,
					async: false,
					success: function(oData, oResponse) {
						window.console.log(oData);
						status = oData.ReturnMsg;
						empName = oData.Name;
						department = oData.Designation;
						plant = oData.PlanPlant;
					
					}
				});
					var detail = {
					"Name":empName,
					"Department":department,
					"Plant":plant
				};
				var sampleModel = new sap.ui.model.json.JSONModel(detail);
				sap.ui.getCore().setModel(sampleModel, 'empInfo');
				
				if (status === "Sucess") {
					window.console.log("Sucess");
					var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					oRouter.navTo("dashboard");
				} else if (status === "Password incorrect") {
					MessageBox.warning("Password Incorrect");
				} else if (status === "User not found") {
					window.console.log("User not Found");
					MessageBox.error("The User Id " + empId + " not Found");
				} else {
					window.console.log("Other error");
				}
			} else {
				MessageBox.alert("Fill all the fields");
			}
		}

	});

});