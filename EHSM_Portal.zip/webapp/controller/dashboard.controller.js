sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter",
	"sap/m/Popover",
	"sap/m/Button"
], function(Controller, JSONModel, Filter, FilterOperator, Sorter,Popover,Button) {
	"use strict";

	return Controller.extend("hariEHSM_Portal.controller.dashboard", {


		oEmployeeModel: new JSONModel(),
		onInit: function() {
			
			var sModel = sap.ui.getCore().getModel("empInfo");
			var myData = sModel.getData();
			window.console.log(myData);
			this.getView().byId("user-btn").setText(myData.Name);
				var mEmployeeData = {
				pages: [{
					header: "Employee Info",
					icon: "sap-icon://customer",
					title: myData.Name,
					description: myData.Department,
						groups: [
							{
								heading: "",
								elements: [
									{
										label: "Plant",
										value:  myData.Plant,
										elementType: sap.m.QuickViewGroupElementType.pageLink,
										pageLinkId: "contactPage"
									}
								]
							}
						]
				}]
			};
	
			this.oEmployeeModel.setData(mEmployeeData);

			var surl = "/sap/opu/odata/sap/ZEHSM_ODATA_HP_SRV/";
			var oModel = new sap.ui.model.odata.ODataModel(surl, true);
			//Local var to loopitems
			var inciModel = new JSONModel();
			var riskModel = new JSONModel();
			// entity name
			oModel.read("ZHP_INCIDENT_LISTSet?$filter=Plant eq '"+ myData.Plant +"'", {
				context: null,
				urlParameters: null,
				async: false,
				success: function(oData, oResponse) {
					window.console.log("OData values:");
					window.console.log(oData);
					window.console.log("OModel Value");
					inciModel.setData(oData);
					//window.console.log(ooModel.getData(oData));
				}

			});

			oModel.read("ZHP_RISK_LSTSet", {
				context: null,
				urlParameters: null,
				async: false,
				success: function(oData, oResponse) {
					window.console.log("OData values:");
					window.console.log(oData);
					window.console.log("OModel Value");
					riskModel.setData(oData);
					//window.console.log(ooModel.getData(oData));
					for (var i = 0; i < oData.results.length; i++) {
						var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
							pattern: "MMM dd, yyyy "
						});
						var dateStr = dateFormat.format(new Date(oData.results[i].Valfr));
						oData.results[i].Valfr = dateStr;
						dateStr = dateFormat.format(new Date(oData.results[i].Valto));
						oData.results[i].Valto = dateStr;
					}

				}

			});

			this.getView().setModel(inciModel, "incidentValue");
			this.getView().setModel(riskModel, "riskValue");
		},
		//Filter Icon Press
		onFilterButtonClickIncident: function() {

			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment("hariEHSM_Portal.view.Fragments.IncidentFilter", this);
			}
			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);
			this._oDialog.open();
		},
		onFilterButtonClickRisk: function() {

			if (!this._oDialog1) {
				this._oDialog1 = sap.ui.xmlfragment("hariEHSM_Portal.view.Fragments.RiskFilter", this);
			}
			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);
			this._oDialog1.open();
		},
		//Exit
		onExit: function() {
			if (this._oDialog) {
				this._oDialog.destroy();
			}
			if (this._oDialog1) {
				this._oDialog1.destroy();
			}
			if (this._oQuickView) {
				this._oQuickView.destroy();
			}
		},
		//Filter sorting grouping
		handleConfirmRisk: function(oEvent) {
			window.console.log("Risk Method");
			var oView = this.getView();
			var oTable = oView.byId("riskTable");

			var mParams = oEvent.getParameters();
			window.console.log(mParams);
			var oBinding = oTable.getBinding("items");
			window.console.log(oBinding);
			// apply sorter to binding
			// (grouping comes before sorting)
			var sPath;
			var bDescending;
			

			var aSorters = [];
			if (mParams.groupItem) {
				sPath = mParams.groupItem.getKey();
				bDescending = mParams.groupDescending;
				aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
				window.console.log("hi");
			}

			sPath = mParams.sortItem.getKey();
			window.console.log(sPath);
			bDescending = mParams.sortDescending;
			window.console.log(bDescending);
			aSorters.push(new Sorter(sPath, bDescending));

			window.console.log(aSorters);
			oBinding.sort(aSorters);
			window.console.log("skipped");

			// apply filters to binding
			var aFilters = [];
			jQuery.each(mParams.filterItems, function(i, oItem) {
				var aSplit = oItem.getKey().split("__");
				var sId = aSplit[0];
				var sValue = aSplit[1];
				//(new Filter("Orderid", FilterOperator.Contains, sQuery));
				window.console.log(sId, sValue);
				var oFilter = new Filter(sId, FilterOperator.Contains, sValue);
				aFilters.push(oFilter);
			});
			oBinding.filter(aFilters);
			window.console.log("last");
			window.console.log(oBinding);

			// update filter bar
			//oView.byId("vsdFilterBar").setVisible(aFilters.length > 0);
			//oView.byId("vsdFilterLabel").setText(mParams.filterString);
		},
		handleConfirmIncident: function(oEvent) {

			var oView = this.getView();
			var oTable = oView.byId("incidentTable");

			var mParams = oEvent.getParameters();
			window.console.log(mParams);
			//window.console.log(oTable);
			var oBinding = oTable.getBinding("items");
			window.console.log(oBinding);
			// apply sorter to binding
			// (grouping comes before sorting)
			var sPath;
			var bDescending;

			var aSorters = [];
			if (mParams.groupItem) {
				sPath = mParams.groupItem.getKey();
				bDescending = mParams.groupDescending;
				aSorters.push(new sap.ui.model.Sorter(sPath, bDescending));
				window.console.log("hi");
			}

			sPath = mParams.sortItem.getKey();
			window.console.log(sPath);
			bDescending = mParams.sortDescending;
			window.console.log(bDescending);
			aSorters.push(new Sorter(sPath, bDescending));

			window.console.log(aSorters);
			oBinding.sort(aSorters);
			window.console.log("skipped");

			// apply filters to binding
			var aFilters = [];
			jQuery.each(mParams.filterItems, function(i, oItem) {
				var aSplit = oItem.getKey().split("__");
				var sId = aSplit[0];
				var sValue = aSplit[1];
				//(new Filter("Orderid", FilterOperator.Contains, sQuery));
				window.console.log(sId, sValue);
				var oFilter = new Filter(sId, FilterOperator.Contains, sValue);
				aFilters.push(oFilter);
			});
			oBinding.filter(aFilters);
			window.console.log("last");
			window.console.log(oBinding);

			// update filter bar
			//oView.byId("vsdFilterBar").setVisible(aFilters.length > 0);
			//oView.byId("vsdFilterLabel").setText(mParams.filterString);
		},
		//SearchField
		onSearch: function(oEvent) {
			var aFilter = [];
			var sQuery = oEvent.getSource().getValue();
			window.console.log(sQuery);
			if (sQuery && sQuery.length > 0) {
				aFilter.push(new Filter("Recn", FilterOperator.Contains, sQuery));
			}
			// filter binding
			window.console.log(aFilter);
			var oList = this.getView().byId("incidentTable");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilter, "Application");

			oList = this.getView().byId("riskTable");
			oBinding = oList.getBinding("items");
			oBinding.filter(aFilter, "Application");
		},
		//Logout
		onHandler: function(event) {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			var logout = new Button({
				text: 'Logout',
				type: sap.m.ButtonType.Transparent,
				press: function() {
					window.console.log("Logout function");
					oRouter.navTo("");
				}
			});
			var popover = new Popover({
				showHeader: false,
				placement: sap.m.PlacementType.Bottom,
				content: [logout]
			}).addStyleClass('sapMOTAPopover sapTntToolHeaderPopover');

			popover.openBy(event.getSource());
		},
		//RowSelect
		onRowSelectIncident:function(){
			
			var oTabModelData = this.getView().byId("incidentTable").getModel("incidentValue");
			//	window.console.log(oTabModelData);
			
			var index = this.getView().byId("incidentTable")._aSelectedPaths[0].split("/")[2];
			window.console.log(index);
			var allRows = oTabModelData.getProperty("/");
			window.console.log(allRows);
			window.console.log("Single result");
			//window.console.log(oTabModelData.getProperty("/").results[index]);
			var data = allRows.results[index];
			window.console.log(data.Recn);

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("incidentdetail", {
				number: data.Recn
			});
		},
		onRowSelectRisk:function(){
		
		var oTabModelData = this.getView().byId("riskTable").getModel("riskValue");
			//	window.console.log(oTabModelData);
			var index = this.getView().byId("riskTable")._aSelectedPaths[0].split("/")[2];
			window.console.log(index);
			var allRows = oTabModelData.getProperty("/");
			window.console.log(allRows);
			window.console.log("Single result");
			//window.console.log(oTabModelData.getProperty("/").results[index]);
			var data = allRows.results[index];
			window.console.log(data.Recn);

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("riskdetail", {
				number: data.Recn
			});
		
		},
		//QuickView
		onAfterRendering: function() {
			var oButton = this.getView().byId('emp_detail');
			oButton.$().attr('aria-haspopup', true);
		},
		openQuickView: function(oEvent, oModel) {
			this.createPopover();

			this._oQuickView.setModel(oModel);

			// delay because addDependent will do a async rerendering and the actionSheet will immediately close without it.
			var oButton = oEvent.getSource();
			jQuery.sap.delayedCall(0, this, function() {
				this._oQuickView.openBy(oButton);
			});
		},
		handleEmployeeQuickViewPress: function(oEvent) {
			this.openQuickView(oEvent, this.oEmployeeModel);
		},
		createPopover: function() {
			if (this._oQuickView) {
				this._oQuickView.destroy();
			}

			this._oQuickView = sap.ui.xmlfragment("hariEHSM_Portal.view.Fragments.employeeFragment", this);
			this.getView().addDependent(this._oQuickView);
		}

	});

});